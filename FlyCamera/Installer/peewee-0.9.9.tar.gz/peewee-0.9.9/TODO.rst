todo
====

* investigate fetching the optimal number of results from the cursor
  as opposed to pulling them off one at a time
